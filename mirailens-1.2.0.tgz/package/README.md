# MiraiLens — MCP Browser Agent

MiraiLens is the browser agent you can watch, interrupt, control, and trust. It implements the Model Context Protocol (MCP) to bridge the gap between advanced AI orchestrators (like Cursor, Claude Desktop, and MCP Inspector) and your web browser, allowing AI assistants to execute operations on your active browser session under strict, client-side safety policies.

---

## Why MiraiLens

Web automation powered by AI assistants can be highly powerful but carries significant risk. MiraiLens is built with security‑first principles:

- **Browser Control**: Enables AI to execute high‑level clicks, input values, dropdown selection, navigation, and keyboard inputs on your active browser tab.
- **Observability**: Exposes detailed visual and structural state inspection (such as screenshots, console log feeds, and ARIA accessibility tree snapshots) to the AI client.
- **Human Approval**: Every consequential browser action (clicks, values, external navigation) requires physical human approval on the browser tab overlay.
- **Extension-side Policy Enforcement**: Enforces security constraints (Trusted Domains, Blocked Domains, and Draft-Only mode) inside the browser context, ensuring the AI cannot bypass policies or run actions silently.
- **Accountability**: Generates an append‑only local execution ledger tracking sessions, actors, actions, decisions, and outcome statuses.
- **Recovery (Undo)**: Supports targeted rollback snapshots for form input values to easily restore previous states without full-page reloads.

---

## Architecture

```text
  +------------+       Model Context Protocol (JSON-RPC)       +------------+
  |    MCP     | <-------------------------------------------> |    MCP     |
  | Orchestrator |                                             |   Server   |
  +------------+                                               +------------+
                                                                     |
                                                           WebSocket | (JSON-RPC)
                                                                     v
  +------------------+     Content Script Overlay     +---------------------+
  |   Active Web     | <----------------------------- |  Browser Extension  |
  |   Tab Overlay    |                                |   (Service Worker)  |
  +------------------+                                +---------------------+
```

- **MCP Client**: Initiates requests for browser automation (e.g. Cursor, Claude Desktop).
- **MCP Server**: Translates MCP request commands into browser-focused WebSocket commands.
- **Browser Extension**: Hosts the core state machine, enforces policies, handles human overlays, captures snapshots, and executes script operations.

---

## Requirements

- **Node.js**: Version 18.0.0 or higher.
- **Browser**: Google Chrome, Chromium, or Microsoft Edge.
- **MCP Client**: Cursor, Claude Desktop, or Model Context Protocol Inspector.
- **Extension Mode**: Developer mode enabled in browser to load extension unpacked.

---

## Installation

### 1. Install & Run MCP Server

To run the MCP server, simply use `npx`:

```bash
npx mirailens@latest
```

This will launch the Model Context Protocol stdio server on your local machine, listening for incoming stdio streams from your MCP client.

### 2. Install Browser Extension

1. Clone this repository locally if you haven't already:
   ```bash
   git clone https://github.com/mugenkyou/mcp-server-mirailens.git
   ```
2. Open your browser and navigate to the Extensions page: `chrome://extensions/`
3. Toggle the **Developer mode** switch in the top right.
4. Click **Load unpacked** in the top left.
5. Select the `extension` folder inside the cloned repository.
6. Note the extension ID and confirm the version is showing `v1.2.0`.

---

## Configuration

### Cursor Configuration

Open your Cursor configuration file (`mcp.json`):

- **Windows**: `%APPDATA%/Cursor/User/globalStorage/cursor.mcp/mcp.json`
- **macOS**: `~/Library/Application Support/Cursor/User/globalStorage/cursor.mcp/mcp.json`
- **Linux**: `~/.config/Cursor/User/globalStorage/cursor.mcp/mcp.json`

Add the server command entry:

```json
{
  "mcpServers": {
    "mirailens": {
      "command": "npx",
      "args": ["-y", "mirailens@latest"],
      "env": {}
    }
  }
}
```

### Claude Desktop Configuration

Open Claude Desktop's configuration file (`claude_desktop_config.json`):

- **Windows**: `%APPDATA%/Claude/claude_desktop_config.json`
- **macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`

Add the server command entry:

```json
{
  "mcpServers": {
    "mirailens": {
      "command": "npx",
      "args": ["-y", "mirailens@latest"]
    }
  }
}
```

---

## First Run

1. Start your local MCP Client (Cursor or Claude Desktop).
2. Click the **MiraiLens** extension icon in your browser toolbar to open the console popup.
3. Click **CONNECT TO MCP SERVER**.
4. Navigate your active tab to a page (e.g. `http://localhost:3000` or a public domain).
5. Request your AI assistant to click an element or type text in the active window.
6. The action overlay will highlight the element and present Approve/Deny buttons. Confirm the action to execute.

---

## Available Tools

- **mcp_mirailens_navigate**: Directs the active browser tab to a new URL.
- **mcp_mirailens_go_back**: Navigates back in history.
- **mcp_mirailens_go_forward**: Navigates forward in history.
- **mcp_mirailens_click**: Simulates a click event on an element.
- **mcp_mirailens_hover**: Simulates hovering over an element.
- **mcp_mirailens_type**: Inputs text into a target field.
- **mcp_mirailens_select_option**: Selects dropdown choice list values.
- **mcp_mirailens_press_key**: Simulates a keyboard key press.
- **mcp_mirailens_wait**: Sleeps browser automation for a specified number of seconds.
- **mcp_mirailens_snapshot**: Captures an accessibility ARIA snapshot tree of the page.
- **mcp_mirailens_get_console_logs**: Retrieves the tab console output.
- **mcp_mirailens_screenshot**: Captures a full-view screenshot.
- **undo_last**: Reverts the last input restoration.
- **get_action_history**: Returns action history logs.

---

## Security Model

The security boundaries of MiraiLens reside inside the extension context:

1. **Extension Enforcement**: The browser extension is the ultimate enforcement authority. It validates client requests independently of the server.
2. **Draft-Only Mode**: When enabled, the extension blocks form submissions (`submit` buttons, `ENTER` keys, form submittals) to prevent accidental mutation while still allowing data-filling.
3. **Sensitive-Field Protection**: The extension identifies password, PIN, CVV, and credit card fields, and blocks AI access unless policy is explicitly set, and automatically redacts all input data in local ledger feeds.
4. **Trusted & Blocked Domains**: Blocked domains are immediately denied. Trusted domains allow low-risk automation to proceed without human overlays, while unknown domains default to approval gating.

---

## Accessibility

MiraiLens is committed to accessibility (A11y):
- **Keyboard Navigation**: Interactive extension pages (popup, settings, history) support tab indexes and keyboard focus states.
- **Accessible Attributes**: Dialogue overlays contain `role="alertdialog"`, `aria-modal="true"`, and standard focus tracking.
- **Information Conveyance**: Color indicators for status changes (approved, blocked, offline) are consistently paired with semantic text labels.

---

## License

Distributed under the **MiraiLens Community Non-Commercial License (Version 1.0)**. See the [LICENSE](LICENSE) file for details.
